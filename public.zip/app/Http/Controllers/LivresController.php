<?php

namespace App\Http\Controllers;

use App\Models\Livres;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\MethodsController;

class LivresController extends Controller
{
    public function index()
    {
        if (Auth::user()->checkPermission('Books', 'read')) {
            return response()->json([
                "data" => Livres::where('deleted', 0)->get()
            ], 200);
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    public function getBooks()
    {
        return response()->json([
            "data" => Livres::where('deleted', 0)->get()
        ], 200);
    }

    public function store(Request $request)
    {
        if (Auth::user()->checkPermission('Books', 'create')) {
            $request->validate([
                "title" => "required",
                "description" => "required",
                "file" => "nullable",
                "image" => "required",
            ]);
            $image = MethodsController::uploadImageUrl($request->image, '/uploads/livres/');
            $file = MethodsController::uploadDoc($request, $request->title, '/uploads/doc/');
            $data = Livres::create([
                "title" => $request->title,
                "description" => $request->description,
                "file" => $request->file ? $file : null,
                "image" => $image,
            ]);
            return response()->json([
                "data" => $data,
                "message" => trans('messages.saved')
            ], 200);
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }
}
