<?php

namespace App\Http\Controllers;

use App\Models\Countries;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CountriesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (Auth::user()->checkPermission('Countries', 'read')) {
            return response()->json([
                "data" => Countries::where('deleted', 0)->get()
            ], 200);
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    public function publicList()
    {
        return response()->json([
            "data" => Countries::where('deleted', 0)->where('status', 1)->get()
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            "name" => "required",
            "code" => "required"
        ]);
        if (Auth::user()->checkPermission('Countries', 'create')) {
            $country = Countries::where('name', $request->name)->where('deleted', 0)->first();
            if ($country) {
                $country->name = $request->name;
                $country->code = $request->code;
                $country->save();
                return response()->json([
                    "data" => $country,
                    "message" => trans('messages.updated')
                ], 200);
            } else {
                $country = new Countries();
                $country->name = $request->name;
                $country->code = $request->code;
                $country->save();
                return response()->json([
                    "data" => $country,
                    "message" => trans('messages.saved')
                ], 200);
            }
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Countries $countries)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (Auth::user()->checkPermission('Countries', 'read')) {
            $country = Countries::where('deleted', 0)->find($id);
            if ($country) {
                return response()->json([
                    "data" => $country
                ], 200);
            } else {
                return response()->json([
                    "message" => trans('messages.notFound')
                ]);
            }
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            "name" => "required|unique:countries,name,".$id,
            "code"=> "required|unique:countries,code,".$id,
        ]);
        if (Auth::user()->checkPermission('Countries', 'update')) {
            $country = Countries::find($id);
            if ($country) {
                $country->name = $request->name;
                $country->code = $request->code;
                $country->save();
                return response()->json([
                    "message" => trans('messages.updated'),
                    "data" => $country
                ], 200);
            } else {
                return response()->json([
                    "message" => trans('messages.notFound')
                ]);
            }
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (Auth::user()->checkPermission('Countries', 'delete')) {
            $country = Countries::where('deleted', 0)->find($id);
            if ($country) {
                $country->deleted = 1;
                $country->save();
                return response()->json([
                    "message" => trans('messages.deleted'),
                ], 200);
            } else {
                return response()->json([
                    "message" => trans('messages.notFound')
                ]);
            }
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }
}
