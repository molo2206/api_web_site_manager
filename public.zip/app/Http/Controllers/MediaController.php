<?php

namespace App\Http\Controllers;

use App\Models\Media;
use Illuminate\Http\Request;
use App\Http\Controllers\MethodsController;

class MediaController extends Controller
{
    public function index($type)
    {
        $data = Media::with('category', 'country')->where('type', $type)->get();
        return response()->json([
            "data" => $data
        ], 200);
    }
    public function store(Request $request)
    {

        if ($request->type == 'photo') {
            $request->validate([
                "cover" => "required",
                "category_id" => "required",
                "country_id" => "required",
                "type" => "required"
            ]);
            foreach ($request->cover as $item) {
                $image = MethodsController::uploadImageUrl($item, '/uploads/media/');
                $data = Media::create([
                    "cover" => $image,
                    "category_id" => $request->category_id,
                    "country_id" => $request->country_id,
                    "type" => "photo"
                ]);
            }
            return response()->json([
                "message" => trans('messages.saved')
            ], 200);
        } else {
            $request->validate([
                "url" => "required",
                "cover" => "required",
                "category_id" => "required",
                "country_id" => "required",
                "type" => "required"
            ]);

            $image = MethodsController::uploadImageUrl($request->cover[0], '/uploads/media/');
            $data = Media::create([
                "url" => $request->url,
                "cover" => $image,
                "category_id" => $request->category_id,
                "country_id" => $request->country_id,
                "type" => "video"
            ]);

            return response()->json([
                "data" => $data,
                "message" => trans('messages.saved')
            ], 200);
        }
    }
}
