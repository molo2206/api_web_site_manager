<?php

namespace App\Http\Controllers;

use App\Models\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\MethodsController;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (Auth::user()->checkPermission('Team', 'read')) {
            return response()->json([
                "data" => Team::where('deleted', 0)->get()
            ], 200);
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }
    public function getTeam()
    {
        return response()->json([
            "data" => Team::where('deleted', 0)->get()
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (Auth::user()->checkPermission('Team', 'create')) {
            $request->validate([
                "full_name" => "required",
                "email" => "required",
                "liens_sociaux" => "nullable",
                "image" => "required",
                "fonction" => "required"
            ]);
            $image = MethodsController::uploadImageUrl($request->image, '/uploads/team/');

            $user = Team::create([
                "full_name" => $request->full_name,
                "email" => $request->email,
                "liens_sociaux" => json_encode($request->liens_sociaux),
                "image" => $image,
                "fonction" => $request->fonction
            ]);
            return response()->json([
                "data" => $user,
                "message" => trans('messages.saved')
            ], 200);
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Team $team)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Team $team)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (Auth::user()->checkPermission('Team', 'create')) {
            $request->validate([
                "full_name" => "required",
                "email" => "required",
                "liens_sociaux" => "nullable",
                "image" => "nullable",
                "fonction" => "required"
            ]);
            $team = Team::where('deleted', 0)->find($id);
            if ($team) {
                if ($request->image) {
                    $image = MethodsController::uploadImageUrl($request->image, '/uploads/team/');
                } else {
                    $image = $team->image;
                }
                if ($request->liens_sociaux) {
                    $sociaux = json_encode($request->liens_sociaux);
                } else {
                    $sociaux = $team->liens_sociaux;
                }

                $team->update([
                    "full_name" => $request->full_name,
                    "email" => $request->email,
                    "liens_sociaux" => $sociaux,
                    "image" => $image,
                    "fonction" => $request->fonction
                ]);
                return response()->json([
                    "data" => $team,
                    "message" => trans('messages.updated')
                ], 200);
            } else {
                return response()->json([
                    "message" => trans('messages.idNotFound')
                ], 422);
            }
        } else {
            return response()->json([
                "message" => trans('messages.notAuthorized')
            ], 422);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Team $team)
    {
        //
    }
}
