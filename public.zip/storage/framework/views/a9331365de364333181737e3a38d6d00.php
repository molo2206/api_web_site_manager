</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div><?php /**PATH D:\Projets\laravel\dici_api\vendor\snowfire\beautymail\src\Snowfire\Beautymail/../../views/templates/minty/contentEnd.blade.php ENDPATH**/ ?>