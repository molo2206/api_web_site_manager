<table height="36" align="center" valign="middle" border="0" cellpadding="0" cellspacing="0" class="tablet-button" st-button="edit">
	<tbody>
	<tr>
		<td width="auto" align="center" valign="middle" height="36" style=" background-color:<?php echo e(Config::get('beautymail.colors.button', '#004cad')); ?>; border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:13px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300;">
	       <span style="color: #ffffff; font-weight: 300;">
	          <a style="color: #ffffff; text-align:center;text-decoration: none;display:block;padding-left:25px; padding-right:25px;background-clip: padding-box;height:36px;line-height: 36px" href="<?php echo e($link); ?>"><?php echo e($text); ?></a>
	       </span>
		</td>
	</tr>
	</tbody>
</table>
<?php /**PATH D:\Projets\laravel\dici_api\vendor\snowfire\beautymail\src\Snowfire\Beautymail/../../views/templates/minty/button.blade.php ENDPATH**/ ?>